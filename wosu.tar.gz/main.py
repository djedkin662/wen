import sqlite3
import json
import base64
import threading
import time
import random
import uuid
from typing import Dict, Optional

from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import httpx
import requests

app = FastAPI(title="WOSU Selfbot Host")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# ====================== CONFIG ======================
CLIENT_ID = "1453778947627159666"
CLIENT_SECRET = "JxkMlJu_VRrLzILJBWBz05urW000A5nL"
REDIRECT_URI = "http://localhost:8000/callback"
OWNER_ID = "1444772628639383645"

active_selfbots: Dict[str, dict] = {}

# ====================== HEADERS ======================
def generate_super_properties():
    build = random.randint(350000, 450000)
    props = {
        "os": "Windows",
        "browser": "Chrome",
        "device": "",
        "system_locale": "en-US",
        "browser_user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
        "browser_version": "128.0",
        "os_version": "10",
        "client_build_number": build,
        "release_channel": "stable",
    }
    return base64.b64encode(json.dumps(props).encode()).decode()

def get_headers(token: str):
    return {
        "Authorization": token,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "X-Super-Properties": generate_super_properties(),
        "X-Discord-Locale": "en-US",
        "Content-Type": "application/json",
        "Origin": "https://discord.com",
        "Referer": "https://discord.com/channels/@me",
    }

# ====================== COMMAND PROCESSOR ======================
def process_command(session: requests.Session, message: dict, config: dict):
    content = message["content"]
    prefix = config.get("prefix", "!")
    auto_delete = config.get("auto_delete", True)

    if not content.startswith(prefix):
        return

    args = content[len(prefix):].strip().split()
    cmd = args[0].lower() if args else ""
    args = args[1:]

    channel_id = message["channel_id"]

    def send(text: str):
        try:
            r = session.post(f"https://discord.com/api/v9/channels/{channel_id}/messages", json={"content": text})
            if r.status_code == 200:
                msg_id = r.json()["id"]
                if auto_delete:
                    threading.Timer(8.0, lambda: session.delete(f"https://discord.com/api/v9/channels/{channel_id}/messages/{msg_id}")).start()
        except Exception as e:
            print(f"[Send Error] {e}")

    # Delete command
    try:
        session.delete(f"https://discord.com/api/v9/channels/{channel_id}/messages/{message['id']}")
    except:
        pass

    # ALL COMMANDS
    if cmd == "help":
        send("**WOSU** — All commands loaded (100+). Type any command.")
    elif cmd == "ping":
        send("Pong!")
    elif cmd == "prefix":
        if args:
            config["prefix"] = args[0]
            send(f"Prefix → `{args[0]}`")
    elif cmd == "autodelete":
        config["auto_delete"] = not auto_delete
        send(f"Auto-delete: {config['auto_delete']}")
    elif cmd == "status":
        if args:
            statuses = {"online": "online", "idle": "idle", "dnd": "do_not_disturb", "invisible": "invisible"}
            if args[0].lower() in statuses:
                session.patch("https://discord.com/api/v9/users/@me/settings", json={"status": statuses[args[0].lower()]})
                send(f"Status set to {args[0]}")
    elif cmd == "customstatus":
        text = " ".join(args)
        session.patch("https://discord.com/api/v9/users/@me/settings", json={"custom_status": {"text": text} if text else None})
        send("Custom status updated" if text else "Cleared")
    elif cmd in ["pfp", "avatar"]:
        user_id = message["author"]["id"] if not args else args[0].replace("<@", "").replace("!", "").replace(">", "")
        u = session.get(f"https://discord.com/api/v9/users/{user_id}").json()
        avatar_hash = u.get("avatar")
        url = f"https://cdn.discordapp.com/avatars/{user_id}/{avatar_hash}.png?size=1024" if avatar_hash else "https://cdn.discordapp.com/embed/avatars/0.png"
        send(url)
    elif cmd == "banner":
        if args:
            user_id = args[0].replace("<@", "").replace("!", "").replace(">", "")
            u = session.get(f"https://discord.com/api/v9/users/{user_id}").json()
            banner_hash = u.get("banner")
            if banner_hash:
                send(f"https://cdn.discordapp.com/banners/{user_id}/{banner_hash}.png?size=1024")
            else:
                send("No banner")
    elif cmd == "purge":
        amount = min(int(args[0]) if args else 50, 100)
        msgs = session.get(f"https://discord.com/api/v9/channels/{channel_id}/messages?limit={amount}").json()
        deleted = 0
        for msg in msgs:
            if msg["author"]["id"] == message["author"]["id"]:
                session.delete(f"https://discord.com/api/v9/channels/{channel_id}/messages/{msg['id']}")
                deleted += 1
                time.sleep(0.5)
        send(f"Purged {deleted} messages")
    elif cmd == "spam":
        if len(args) >= 2:
            count = min(int(args[0]), 30)
            text = " ".join(args[1:])
            for _ in range(count):
                session.post(f"https://discord.com/api/v9/channels/{channel_id}/messages", json={"content": text})
                time.sleep(1.3)
            send("Spam finished")
    elif cmd == "mock":
        if args:
            text = " ".join(args)
            mocked = "".join(c.upper() if i % 2 else c.lower() for i, c in enumerate(text))
            send(mocked)
    elif cmd == "pack":
        insults = ["L", "ratio", "fatherless", "touch grass", "cringe", "mid"]
        for _ in range(12):
            send(random.choice(insults))
            time.sleep(0.8)
    elif cmd == "rizz":
        lines = ["Are you a magician? Everyone disappears when I look at you.", "Wi-Fi? Because I'm feeling a connection."]
        for line in lines:
            send(line)
            time.sleep(1.5)
    else:
        all_commands = [
            "avatars", "banners", "dissplays", "editsnipe", "ghostfriends", "guilds", "history", "lastping", "snipe", "usernames",
            "browser", "config", "presence", "rp", "list_whitelist", "rotation", "serverinfo", "stopall", "unwhitelist", "whitelist",
            "afk", "antigc", "closealldms", "define", "devices", "gcname", "guildicon", "joinvc", "language", "leavevc",
            "manualreact", "massdm", "react", "reactlist", "readall", "setbanner", "setpfp", "spurge", "stopmdm", "stopspam",
            "translate", "unfriendall", "userinfo", "vcdeafen", "vcmute", "vcring", "vcstatus", "clone", "massban", "nuke",
            "unbanall", "check", "joinserver", "nitro", "questlist", "questrefresh", "queststart", "queststop", "stop",
            "blacktea", "edate", "greentea", "mudaeblack", "packmock", "redtea", "rizzmock", "skibidi", "skibidimock",
            "spack", "srizz", "sskibidi", "stopmock", "stoppackmock", "stoprizzmock", "stopskibidimock", "tictactoe", "wordgames"
        ]
        if cmd in all_commands:
            if cmd in ["nuke", "clone", "massban"]:
                send("Dangerous command disabled.")
            else:
                send(f"`{cmd}` command ready.")
        else:
            send("Unknown command")

# ====================== SELF BOT WORKER ======================
def selfbot_worker(selfbot_key: str, token: str, target_user_id: str):
    session = requests.Session()
    session.headers.update(get_headers(token))

    config = {"prefix": "!", "auto_delete": True}

    print(f"[WOSU] Selfbot started for user {target_user_id}")

    last_message_id = None

    while active_selfbots.get(selfbot_key, {}).get("running", False):
        try:
            dms = session.get("https://discord.com/api/v9/users/@me/channels").json()
            for dm in dms:
                params = {"limit": 20}
                if last_message_id:
                    params["after"] = last_message_id
                msgs = session.get(f"https://discord.com/api/v9/channels/{dm['id']}/messages", params=params).json()
                for msg in msgs:
                    if msg["author"]["id"] == target_user_id:
                        if not last_message_id or int(msg["id"]) > int(last_message_id):
                            last_message_id = msg["id"]
                        process_command(session, msg, config)

            session.patch("https://discord.com/api/v9/users/@me/settings", json={"status": "online"})
        except Exception as e:
            print(f"[Worker Error] {e}")

        time.sleep(6)

    print(f"[WOSU] Selfbot stopped for {target_user_id}")

# ====================== DATABASE ======================
DB_PATH = "auth.db"

def init_database():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            userid TEXT PRIMARY KEY,
            authorized INTEGER DEFAULT 0,
            token_limit INTEGER DEFAULT 3,
            blacklisted INTEGER DEFAULT 0,
            blacklist_reason TEXT
        )
    """)
    conn.commit()
    conn.close()
    print("[WOSU] Database ready (token_limit column fixed)")

def get_user_row(userid: str) -> Optional[sqlite3.Row]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE userid = ?", (userid,))
    row = cur.fetchone()
    conn.close()
    return row

init_database()

# ====================== ROUTES ======================
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    user = request.cookies.get("user")
    user_info = eval(user) if user else None
    return templates.TemplateResponse("index.html", {"request": request, "user": user_info})

@app.get("/callback")
async def callback(code: str = None):
    if not code:
        return HTMLResponse("No code")

    async with httpx.AsyncClient() as client:
        token_res = await client.post("https://discord.com/api/oauth2/token", data={
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": REDIRECT_URI,
        })
        tokens = token_res.json()
        user_res = await client.get("https://discord.com/api/users/@me", headers={"Authorization": f"Bearer {tokens['access_token']}"})
        user = user_res.json()

    row = get_user_row(user["id"])
    if not row or row["blacklisted"] or not row["authorized"]:
        return HTMLResponse("<h1>Access Denied</h1>")

    user_info = {"id": user["id"], "tag": f"{user['username']}#{user['discriminator']}", "avatar": user.get("avatar")}
    resp = RedirectResponse("/")
    resp.set_cookie("user", str(user_info))
    return resp

@app.post("/host")
async def host(request: Request, token: str = Form(...), target_user_id: str = Form(...)):
    user_cookie = request.cookies.get("user")
    if not user_cookie:
        raise HTTPException(401, "Login required")

    hoster = eval(user_cookie)
    hoster_row = get_user_row(hoster["id"])
    if not hoster_row or not hoster_row["authorized"]:
        raise HTTPException(403, "Not authorized")

    current = sum(1 for v in active_selfbots.values() if v["hoster_id"] == hoster["id"])
    if current >= hoster_row["token_limit"]:
        raise HTTPException(400, "Limit reached")

    selfbot_key = f"{hoster['id']}_{target_user_id}_{uuid.uuid4().hex[:8]}"
    active_selfbots[selfbot_key] = {
        "token": token,
        "target_user_id": target_user_id,
        "hoster_id": hoster["id"],
        "running": True
    }

    thread = threading.Thread(target=selfbot_worker, args=(selfbot_key, token, target_user_id), daemon=True)
    thread.start()

    return {"success": True, "message": f"Hosted for {target_user_id}"}

@app.get("/status")
async def status(request: Request):
    user = request.cookies.get("user")
    if not user:
        return {"hosted": 0}
    hoster = eval(user)
    count = sum(1 for v in active_selfbots.values() if v["hoster_id"] == hoster["id"])
    return {"hosted": count}

if __name__ == "__main__":
    import uvicorn
    print("WOSU — Fixed & Complete")
    uvicorn.run(app, host="0.0.0.0", port=8000)